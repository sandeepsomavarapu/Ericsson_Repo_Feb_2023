package com.ericsson.service;

import java.util.Set;

import com.ericcson.dao.EmployeeDaoImpl;
import com.ericcson.dao.IEmployeeDao;
import com.ericcson.model.Employee;

public class EmployeeService implements IEmployeeService {

	IEmployeeDao dao = new EmployeeDaoImpl();

	@Override
	public String addEmployee(Employee emp) {

		return dao.addEmployee(emp);
	}

	@Override
	public String updateEmployee(Employee emp) {

		return dao.updateEmployee(emp);
	}

	@Override
	public String deleteEmployee(int empId) {

		return dao.deleteEmployee(empId);
	}

	@Override
	public Employee getEmployee(int empId) {

		return dao.getEmployee(empId);
	}

	@Override
	public Set<Employee> getAllEmployees() {

		return dao.getAllEmployees();
	}

	@Override
	public Set<Employee> getAllEmployeesInBetween(int intialSal, int finalSal) {

		return dao.getAllEmployeesInBetween(intialSal, finalSal);
	}

	@Override
	public Set<Employee> getAllEmployeesByLocation(String location) {

		return dao.getAllEmployeesByLocation(location);
	}

}
