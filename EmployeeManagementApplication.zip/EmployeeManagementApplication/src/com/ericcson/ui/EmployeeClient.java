package com.ericcson.ui;

import java.util.Scanner;
import java.util.Set;

import com.ericcson.model.Employee;
import com.ericsson.service.EmployeeService;
import com.ericsson.service.IEmployeeService;

public class EmployeeClient {

	public static void main(String[] args) {
		int empId = 0;
		String empName = null;
		int empSal = 0;
		String location = null;
		String designation = null;
		IEmployeeService service = new EmployeeService();
		System.out.println("*********Employee Management Application*******");
		while (true) {
			System.out.println("1.Add Employee");
			System.out.println("2.Update Employee");
			System.out.println("3.Delete Employee");
			System.out.println("4.Get Employee By Id");
			System.out.println("5.Get All Employees");
			System.out.println("6.Get All Employees Between Salaries");
			System.out.println("7.Get Employees By Location");

			Scanner scan = new Scanner(System.in);
			int option = scan.nextInt();

			switch (option) {
			case 1:
				System.out.println("Enter Info To Add Employee");
				System.out.println("Enter Employee Id ");
				empId = scan.nextInt();
				System.out.println("Enter Employee Name ");
				empName = scan.next();
				System.out.println("Enter Employee Salary ");
				empSal = scan.nextInt();
				System.out.println("Enter Employee Desgination ");
				designation = scan.next();
				System.out.println("Enter Employee Location ");
				location = scan.next();
				Employee emp = new Employee(empId, empName, empSal, location, designation);
				System.out.println(service.addEmployee(emp));
				break;
			case 2:
				System.out.println("Enter Info To Update Employee");
				System.out.println("Enter Employee Exsisting Id ");
				empId = scan.nextInt();
				System.out.println("Enter Employee Name ");
				empName = scan.next();
				System.out.println("Enter Employee Salary ");
				empSal = scan.nextInt();
				System.out.println("Enter Employee Desgination ");
				designation = scan.next();
				System.out.println("Enter Employee Location ");
				location = scan.next();
				Employee emp1 = new Employee(empId, empName, empSal, location, designation);
				System.out.println(service.updateEmployee(emp1));
				break;

			case 3:
				System.out.println("Enter Employee Exsisting Id ");
				empId = scan.nextInt();
				System.out.println(service.deleteEmployee(empId));
				break;

			case 4:
				System.out.println("Enter Employee Exsisting Id ");
				empId = scan.nextInt();
				System.out.println(service.getEmployee(empId));
				break;

			case 5:
				System.out.println("All Employees Info:");
				Set<Employee> emps = service.getAllEmployees();
				emps.stream().forEach(System.out::println);
				break;

			case 6:
				System.out.println("All Employees Info Inbetween Salary:");
				System.out.println("Enter Employee IntialSalary ");
				empSal = scan.nextInt();
				System.out.println("Enter Employee FinalSalary ");
				int empSal1 = scan.nextInt();
				Set<Employee> emps1 = service.getAllEmployeesInBetween(empSal, empSal1);
				emps1.stream().forEach(System.out::println);
				break;

			case 7:
				System.out.println("All Employees Info By Location:");
				System.out.println("Enter Employee Location ");
				location = scan.next();
				Set<Employee> emps2 = service.getAllEmployeesByLocation(location);
				emps2.stream().forEach(System.out::println);
				break;

			default:
				System.out.println("Thank You !!!!");
				System.exit(0);
				break;
			}
		}
	}

}
