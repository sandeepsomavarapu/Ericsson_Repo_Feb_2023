package com.ericcson.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.ericcson.model.Employee;

public class EmployeeDaoImpl implements IEmployeeDao {

	HashMap<Integer, Employee> emps = new HashMap<Integer, Employee>();

	@Override
	public String addEmployee(Employee emp) {
		emps.put(emp.getEmpId(), emp);
		return "Employee Inserted Successfully";
	}

	@Override
	public String updateEmployee(Employee emp) {
		emps.put(emp.getEmpId(), emp);
		return "Employee Updated Successfully";
	}

	@Override
	public String deleteEmployee(int empId) {
		emps.remove(empId);
		return "Employee Deleted Successfully";
	}

	@Override
	public Employee getEmployee(int empId) {

		return emps.get(empId);
	}

	@Override
	public Set<Employee> getAllEmployees() {
		HashSet<Employee> employees = new HashSet<Employee>();
		Set<Integer> keys = emps.keySet();
		Iterator<Integer> itr = keys.iterator();
		while (itr.hasNext()) {
			int key = itr.next();
			employees.add(emps.get(key));
		}
		return employees;
	}

	@Override
	public Set<Employee> getAllEmployeesInBetween(int intialSal, int finalSal) {// 1000 2000

		HashSet<Employee> employees = new HashSet<Employee>();// 500
		Set<Integer> keys = emps.keySet();
		Iterator<Integer> itr = keys.iterator();
		while (itr.hasNext()) {
			int key = itr.next();
			Employee emp = emps.get(key);
			int empSalary = emp.getEmpSal();
			if (empSalary >= intialSal && empSalary <= finalSal)
				employees.add(emp);
		}
		return employees;
	}

	@Override
	public Set<Employee> getAllEmployeesByLocation(String location) {
		HashSet<Employee> employees = new HashSet<Employee>();
		Set<Integer> keys = emps.keySet();
		Iterator<Integer> itr = keys.iterator();
		while (itr.hasNext()) {
			int key = itr.next();
			Employee emp = emps.get(key);
			if (emp.getLocation().equalsIgnoreCase(location))
				employees.add(emp);
		}
		return employees;
	}

}
