package com.ericcson.dao;

import java.util.Set;

import com.ericcson.model.Employee;

public interface IEmployeeDao {
	public abstract String addEmployee(Employee emp);

	public abstract String updateEmployee(Employee emp);

	public abstract String deleteEmployee(int empId);

	public abstract Employee getEmployee(int empId);

	public abstract Set<Employee> getAllEmployees();

	public abstract Set<Employee> getAllEmployeesInBetween(int intialSal, int finalSal);

	public abstract Set<Employee> getAllEmployeesByLocation(String location);
}
