package com.ericcson.model;

public class Employee {
	private int empId;
	private String empName;
	private int empSal;
	private String location;
	private String designation;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpSal() {
		return empSal;
	}

	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", location=" + location
				+ ", designation=" + designation + "]";
	}

	public Employee(int empId, String empName, int empSal, String location, String designation) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.location = location;
		this.designation = designation;
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}
}
