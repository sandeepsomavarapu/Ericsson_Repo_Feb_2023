package com.cg.demo;

public class Employee {

	private Integer id;
	private String name;
	private Double salary;
	private String designation;
	private String location;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(Integer id, String name, Double salary, String designation, String location) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.location = location;
	}

	//generate setters, getters and toString

}
